module.exports = function (gameServer, split) {
  console.log("[Console] Cleared " + gameServer.whlist.length + " IP's");
  gameServer.whlist = [];

};
