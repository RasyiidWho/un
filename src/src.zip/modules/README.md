## Modules Folder
This is where the modules for ini (configs) and log and also where commands are.


Commands are listed in commandlist.js and each command is in the commands folder
