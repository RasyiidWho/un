var Commands = require('./modules/CommandList');
var Multiverse = require('./core/Multiverse');

var Multiverse = new Multiverse('1.0.0');

setTimeout(function () {
  process.exit(0);
}, 60000);

process.exit(0);
